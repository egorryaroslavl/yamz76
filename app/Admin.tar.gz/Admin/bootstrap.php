<?php

/* PackageManager::load('admin-default')
    ->css('extend', resources_url('css/common-extend.css'));*/
