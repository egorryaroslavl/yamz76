<?php

Route::get('', ['as' => 'admin.dashboard', function () {
	$content = 'Не выбран раздел...';
	return AdminSection::view($content, 'Главная');
}]);

