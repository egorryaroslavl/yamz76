<?php

	use SleepingOwl\Admin\Navigation\Page;


	return [
		[
			'title' => 'Главная',
			'icon'  => 'fa fa-home',
			'url'   => route( 'admin.dashboard' ),
		],


	];